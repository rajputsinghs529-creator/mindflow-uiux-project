# MindFlow — Meditation & Wellness App (UI/UX Minor Project)

**Author:** Kishanraj Singh
**Program:** UI/UX Design — September Batch, Naviotech Solution Pvt Ltd
**Project:** Minor Project — Meditation or Wellness App
**Design tool:** Figma (interactive prototype)
**Code:** React Native (Expo) implementation of the same design

---

## 1. Project Overview

MindFlow is a simple, calming meditation and wellness app designed for people who are new to meditation. The app helps users check in with their mood, discover short guided sessions (stress relief, mindful breathing, sleep soundscapes) and build a daily mindfulness habit without feeling overwhelmed.

The project has two parts:

1. **UI/UX design** — a clickable Figma prototype (Onboarding → Sign up / Log in → Home).
2. **Front-end code** — the same screens built in React Native so the design can run on a real phone.

## 2. Problem Statement

New users often find meditation apps overwhelming: too many categories, cluttered home screens, long sign-up flows and no guidance on where to begin. This leads to people dropping off before they complete even one session.

**Goal:** Design a clean, low-effort experience where a first-time user can sign up quickly, tell the app how they feel, and start a relevant session within a few taps.

See [`docs/PROJECT_DESCRIPTION.md`](docs/PROJECT_DESCRIPTION.md) for the full project description, competitor research and design decisions.

## 3. Screens

| # | Screen | Purpose | Key elements |
|---|--------|---------|--------------|
| 1 | Onboarding | First impression, brand introduction | App logo, headline/tagline, background image, **Get Started** CTA, "Already have an account? Log in" link |
| 2 | Sign Up | Create a new account | Logo, title, Full Name, Email, Password, **Create Account** button, "Log in" link |
| 3 | Log In | Returning users | Logo, Email, Password, **Log In** button, "Sign up" link |
| 4 | Home | Landing screen after login | Status bar, greeting with user's name, search bar, mood selector, Explore Sessions cards, bottom navigation bar |

### Prototype flow

```
Onboarding ──Get Started──▶ Sign Up ──Create Account──▶ Home
    │                          ▲  │
    └──Log in link──▶ Log In ──┘  └──Log in link──▶ Log In ──Log In──▶ Home
```

Screenshots of every screen are available in [`docs/screenshots/`](docs/screenshots/).

## 4. Figma Prototype

🔗 **Figma link:** `PASTE_YOUR_FIGMA_PROTOTYPE_LINK_HERE`

(Open the link and press the ▶ Present button to click through the prototype.)

## 5. Design System

Design tokens were saved as Figma variables and are mirrored in [`theme/colors.js`](theme/colors.js).

**Colors**

| Token | Hex | Usage |
|-------|-----|-------|
| primary | `#4DB6AC` | Buttons, active states, logo badge |
| secondary | `#CE85E5` | Accents |
| background | `#F5F5F5` | App background |
| text-primary | `#212121` | Headings, main text |
| text-secondary | `#757575` | Placeholders, sub text |
| mood-calm | `#DCEEE0` | Soft mint circle |
| mood-anxious | `#FDEBD9` | Soft peach circle |
| mood-loved | `#FBE4E8` | Soft pink circle |
| mood-stressed | `#E8E1F5` | Soft lavender circle |

**Typography:** Heading 24 / Semi-bold, Subheading 16 / Regular, Body 14 / Regular, Button 16 / Medium.

**Icons & imagery:** Simple, friendly icons and emoji inside pastel circles; calming yoga/meditation photography on the entry screens with a dark overlay for text readability.

**Components (Figma):** CTA button, input field, mood circle, session card, bottom navigation bar.

## 6. Tech Stack (code)

- [React Native](https://reactnative.dev/) with [Expo](https://expo.dev/)
- [React Navigation](https://reactnavigation.org/) (native stack)

## 7. Folder Structure

```
mindflow-app/
├── App.js                    # Navigation setup
├── app.json                  # Expo configuration
├── package.json              # Dependencies and scripts
├── theme/
│   └── colors.js             # Colors and text styles (Figma variables equivalent)
├── screens/
│   ├── OnboardingScreen.js
│   ├── SignUpScreen.js
│   ├── LoginScreen.js
│   └── HomeScreen.js
└── docs/
    ├── PROJECT_DESCRIPTION.md
    └── screenshots/          # Exported Figma screens
```

## 8. Getting Started

**Prerequisites:** [Node.js](https://nodejs.org) (LTS, v18+) and the **Expo Go** app on your phone.

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/mindflow-app.git
cd mindflow-app

# 2. Install dependencies
npm install

# 3. Start the app
npx expo start
```

Scan the QR code with Expo Go (phone and computer must be on the same Wi-Fi). Changes to any `.js` file refresh the app automatically.

## 9. Current Limitations

- There is no backend or database, so **Sign Up / Log In do not verify or store data** — the buttons simply navigate to the Home screen.
- Bottom navigation tabs (Meditate, Sleep) only highlight; they do not open separate screens yet.
- Mood cards and session cards are static.

## 10. Future Scope

- Real authentication (Firebase / Supabase)
- Meditate and Sleep screens with audio playback
- Mood tracking history and daily streaks
- Dark mode and notifications/reminders

## 11. Acknowledgements

- Project brief and guidance: Naviotech Solution Pvt Ltd
- Photography: Unsplash (placeholder images in the code)
