# MindFlow — Project Description

## 1. Brief description

MindFlow is a meditation and wellness mobile app for first-time users. It keeps the experience simple: a welcoming onboarding screen, a short sign-up / log-in flow, and a home screen where the user can pick how they feel and jump into a relevant session (Stress Relief, Mindful Breathing, Sleep Soundscapes).

The design focuses on calm colors, generous spacing, soft pastel circles and clear call-to-action buttons so the app feels relaxing from the very first screen.

## 2. Problem statement

Beginners often abandon meditation apps early because:

- the home screen shows too many categories and options at once,
- sign-up is long or confusing,
- it is not obvious which session to start with.

**How might we** help a new user go from opening the app to starting a suitable session in just a few taps, while keeping the interface calm and uncluttered?

## 3. Target users

- Students and working professionals dealing with everyday stress
- People who struggle to sleep
- Complete beginners who have never used a meditation app

## 4. Competitor research

> Note: this section summarises commonly seen design patterns in popular meditation apps such as **Calm**, **Headspace** and **Insight Timer**. Review it against the apps yourself and add your own screenshots/observations before final submission.

| Pattern | What popular apps do | How MindFlow applies it |
|---------|---------------------|------------------------|
| Onboarding | Full-screen calming imagery, a short welcome message and one main button | Yoga photo background, tagline, single **Get Started** CTA |
| Color palette | Soft, low-contrast blues, greens and warm neutrals | Teal primary with pastel mint, peach, pink and lavender accents |
| Mood check-in | A quick "how are you feeling?" prompt to personalise content | Mood selector row on the Home screen |
| Session discovery | Sessions grouped by need (sleep, stress, focus, breathing) | "Explore Sessions" cards: Stress Relief, Mindful Breathing, Sleep Soundscapes |
| Navigation | Bottom navigation bar with 3–5 clear tabs | Home, Meditate, Sleep tabs |
| Typography & spacing | Large friendly headings, lots of white space | Clear heading / body hierarchy, rounded cards, generous padding |

### Key takeaways

1. Keep the first screen minimal with one obvious action.
2. Use calm colors and soft shapes to reduce anxiety.
3. Personalise early (mood) instead of showing everything at once.
4. Keep navigation shallow and predictable.

## 5. Design decisions

- **Background photography with a dark overlay** on Onboarding, Sign Up and Log In so white text stays readable.
- **Light background on Home** for a clean, airy feel; dark text for readability.
- **Pastel circles** behind mood and session icons to add color without visual noise.
- **Consistent components** (buttons, inputs, cards) reused across screens to keep the interface predictable.
- **Design tokens as Figma variables** (colors, typography, icons) so the whole design can be updated from one place.

## 6. Screen-by-screen breakdown

### Onboarding
Logo, headline, tagline, illustration/photo, **Get Started** button, and a "Log in" link for returning users.

### Sign Up
Logo/title, Full Name, Email and Password fields, **Create Account** button, optional Google / Facebook sign-up icons, and a link to Log In.

### Log In
Logo/title, Email and Password fields, **Log In** button and a link to Sign Up.

### Home
Status bar, greeting with the user's name, search bar, "How are you feeling?" mood selector, "Explore Sessions" cards and a bottom navigation bar with Home, Meditate and Sleep.

## 7. Interactive prototype (Figma)

- Colors, typography and icons saved as variables
- Reusable components for buttons, inputs and cards
- Clickable connections between all four screens
- Smart-animate transitions between screens
- Flow starting point set on the Onboarding screen

## 8. Tools used

Figma (design + prototype), React Native / Expo (code), GitHub (version control and submission).
