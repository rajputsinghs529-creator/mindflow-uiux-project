import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { colors, fonts } from '../theme/colors';

const moods = [
  { emoji: '🧘', label: 'Calm', color: colors.moodCalm },
  { emoji: '🥴', label: 'Anxious', color: colors.moodAnxious },
  { emoji: '❤️', label: 'Loved', color: colors.moodLoved },
  { emoji: '😱', label: 'Stressed', color: colors.moodStressed },
];

const sessions = [
  { emoji: '😔', label: 'Stress Relief', color: colors.moodAnxious },
  { emoji: '🌿', label: 'Mindful Breathing', color: colors.moodCalm },
  { emoji: '🌙', label: 'Sleep Soundscapes', color: colors.moodStressed },
];

export default function HomeScreen({ navigation }) {
  const [activeTab, setActiveTab] = React.useState('Home');

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.greeting}>Hello, Kishan</Text>
          <Image
            source={{ uri: 'https://i.pravatar.cc/100' }}
            style={styles.avatar}
          />
        </View>

        <View style={styles.searchBar}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Search sessions"
            placeholderTextColor={colors.textSecondary}
          />
        </View>

        <Text style={styles.sectionTitle}>How are you feeling?</Text>
        <View style={styles.moodRow}>
          {moods.map((mood) => (
            <View key={mood.label} style={styles.moodItem}>
              <View style={[styles.moodCircle, { backgroundColor: mood.color }]}>
                <Text style={styles.moodEmoji}>{mood.emoji}</Text>
              </View>
              <Text style={styles.moodLabel}>{mood.label}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Explore Sessions</Text>
        <View style={styles.sessionRow}>
          {sessions.map((session) => (
            <View key={session.label} style={styles.sessionCard}>
              <View style={[styles.sessionCircle, { backgroundColor: session.color }]}>
                <Text style={styles.sessionEmoji}>{session.emoji}</Text>
              </View>
              <Text style={styles.sessionLabel}>{session.label}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <View style={styles.bottomNav}>
        {['Home', 'Meditate', 'Sleep'].map((tab) => (
          <TouchableOpacity key={tab} onPress={() => setActiveTab(tab)} style={styles.navItem}>
            <Text
              style={[
                styles.navLabel,
                activeTab === tab && { color: colors.primary, fontWeight: '600' },
              ]}
            >
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  scrollContent: { padding: 20, paddingTop: 60 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  greeting: { ...fonts.heading, color: colors.textPrimary },
  avatar: { width: 40, height: 40, borderRadius: 20 },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginTop: 20,
  },
  searchIcon: { marginRight: 8 },
  searchInput: { flex: 1, color: colors.textPrimary, ...fonts.body },
  sectionTitle: { ...fonts.heading, fontSize: 18, color: colors.textPrimary, marginTop: 24, marginBottom: 12 },
  moodRow: { flexDirection: 'row', justifyContent: 'space-between' },
  moodItem: { alignItems: 'center', width: '23%' },
  moodCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  moodEmoji: { fontSize: 24 },
  moodLabel: { ...fonts.body, fontSize: 12, color: colors.textPrimary, marginTop: 6, textAlign: 'center' },
  sessionRow: { flexDirection: 'row', justifyContent: 'space-between' },
  sessionCard: { alignItems: 'center', width: '31%' },
  sessionCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sessionEmoji: { fontSize: 26 },
  sessionLabel: { ...fonts.body, fontSize: 12, color: colors.textPrimary, marginTop: 8, textAlign: 'center' },
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    backgroundColor: colors.surface,
  },
  navItem: { alignItems: 'center' },
  navLabel: { ...fonts.body, color: colors.textSecondary },
});
