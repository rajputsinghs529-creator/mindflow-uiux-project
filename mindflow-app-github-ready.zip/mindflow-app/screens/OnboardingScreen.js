import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';
import { colors, fonts } from '../theme/colors';

export default function OnboardingScreen({ navigation }) {
  return (
    <ImageBackground
      source={{ uri: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800' }}
      style={styles.background}
    >
      <View style={styles.overlay} />

      <View style={styles.content}>
        <View style={styles.logoCircle}>
          <Text style={styles.logoEmoji}>🌙</Text>
        </View>
        <Text style={styles.appName}>MindFlow</Text>
        <Text style={styles.tagline}>Find your calm, one breath at a time</Text>

        <View style={styles.bottomSection}>
          <TouchableOpacity
            style={styles.ctaButton}
            onPress={() => navigation.navigate('SignUp')}
          >
            <Text style={styles.ctaText}>Get Started</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
            <Text style={styles.loginLink}>
              Already have an account? <Text style={styles.loginLinkBold}>Log in</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: { flex: 1, justifyContent: 'space-between' },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.35)',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 80,
    paddingHorizontal: 24,
  },
  logoCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
  },
  logoEmoji: { fontSize: 30 },
  appName: { ...fonts.heading, color: colors.white, marginTop: 16 },
  tagline: {
    ...fonts.subheading,
    color: colors.white,
    marginTop: 6,
    textAlign: 'center',
  },
  bottomSection: { width: '100%', alignItems: 'center' },
  ctaButton: {
    backgroundColor: colors.primary,
    width: '100%',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 16,
  },
  ctaText: { ...fonts.button, color: colors.white },
  loginLink: { ...fonts.body, color: colors.white },
  loginLinkBold: { color: colors.primary, fontWeight: '600' },
});
