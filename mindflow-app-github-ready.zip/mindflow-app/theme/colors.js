// Yeh file Figma ke "Variables" collection jaisa kaam karti hai.
// Jahan bhi color chahiye, isse import karke use karo — taaki sab jagah consistent rahe.

export const colors = {
  primary: '#4DB6AC',      // teal
  secondary: '#CE85E5',    // purple
  background: '#F5F5F5',   // off-white
  surface: '#FFFFFF',
  textPrimary: '#212121',
  textSecondary: '#757575',
  white: '#FFFFFF',

  // Mood selector ke pastel colors
  moodCalm: '#DCEEE0',
  moodAnxious: '#FDEBD9',
  moodLoved: '#FBE4E8',
  moodStressed: '#E8E1F5',
};

export const fonts = {
  heading: { fontSize: 24, fontWeight: '600' },
  subheading: { fontSize: 16, fontWeight: '400' },
  body: { fontSize: 14, fontWeight: '400' },
  button: { fontSize: 16, fontWeight: '500' },
};
